prompt --application/shared_components/security/authentications/custom_authentication
begin
--   Manifest
--     AUTHENTICATION: Custom Authentication
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>19108620902970952855
,p_default_application_id=>198710
,p_default_id_offset=>0
,p_default_owner=>'MIHAIBARB87'
);
wwv_flow_api.create_authentication(
 p_id=>wwv_flow_api.id(30802876426173620138)
,p_name=>'Custom Authentication'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function login_apex  ',
'(pi_username IN varchar2,',
' pi_password IN varchar2',
' )',
'return boolean',
'as',
'',
'v_result number;',
'begin',
'select 1 into v_result from Utilizatori',
'where utilizator = pi_username',
'and parola = pi_password;',
'',
'return true;',
'',
'Exception',
'when no_data_found then',
'return false;',
'end login_apex;'))
,p_invalid_session_type=>'LOGIN'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_switch_in_session_yn=>'Y'
);
wwv_flow_api.component_end;
end;
/
