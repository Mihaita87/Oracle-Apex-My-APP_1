prompt --application/shared_components/user_interface/lovs/demo_product_info_product_name
begin
--   Manifest
--     DEMO_PRODUCT_INFO.PRODUCT_NAME
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>19108620902970952855
,p_default_application_id=>198710
,p_default_id_offset=>0
,p_default_owner=>'MIHAIBARB87'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(40694002851681487625)
,p_lov_name=>'DEMO_PRODUCT_INFO.PRODUCT_NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'DEMO_PRODUCT_INFO'
,p_return_column_name=>'PRODUCT_ID'
,p_display_column_name=>'PRODUCT_NAME'
,p_default_sort_column_name=>'PRODUCT_NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_api.component_end;
end;
/
