prompt --application/shared_components/navigation/lists/desktop_navigation_menu
begin
--   Manifest
--     LIST: Desktop Navigation Menu
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.10.01'
,p_release=>'20.2.0.00.20'
,p_default_workspace_id=>19108620902970952855
,p_default_application_id=>198710
,p_default_id_offset=>0
,p_default_owner=>'MIHAIBARB87'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(40693827540875487451)
,p_name=>'Desktop Navigation Menu'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_api.id(40693969465333487557)
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40693985795304487594)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Date Info'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-calendar-o'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40693987687041487598)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Dashboard'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-tachometer'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40693998992450487611)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Order tracking'
,p_list_item_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-arrows-alt'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40731429605302405605)
,p_list_item_display_sequence=>50
,p_list_item_link_text=>'Home'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.:::'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'1,7,25'
);
wwv_flow_api.create_list_item(
 p_id=>wwv_flow_api.id(40694100395001487870)
,p_list_item_display_sequence=>10000
,p_list_item_link_text=>'Administration'
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:'
,p_list_item_icon=>'fa-user-wrench'
,p_security_scheme=>wwv_flow_api.id(40693971554498487560)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_api.component_end;
end;
/
